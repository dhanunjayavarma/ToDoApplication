var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');

var urlencodeParser= bodyParser.urlencoded({extended: true});

var MongoClient = require('mongodb').MongoClient,
    assert=require('assert');
var url = "mongodb://localhost:27017/todo";
/* GET home page. */
var person={
      name:"jeff",
      age:30
}

router.get('/', function(req, res, next) {
  res.render('sing2');
});
router.post('/users/add', urlencodeParser, function(req, res, next)
{
    MongoClient.connect(url, function(err, db) {
        assert.equal(null ,err);
        // console.log(req.body.email+"---------"+req.body.pw);
        db.collection('signup').findOne({$and:[{"email": req.body.email}, {"pw": req.body.pw}]},function(err,result){
            if(err)
                throw err;
            if(result === null) {
                console.log("Enter Correct Details");
                res.render('sing2');
            }
            else
            {
                console.log("Sucessfull");
                db.collection('task').find({"email":req.body.email,"status":0}).toArray(function(err,items){
                    if(err) throw err;
                    db.collection('task').find({"email":req.body.email,"status":1}).toArray(function (err, comp) {
                        if(err) throw err;
                        res.render('todo',{email:req.body.email,item:items,completed:comp});
                    });

                });
















            }

        });
    });


 // console.log(req.body.first_name+req.body.pw);

});
router.post('/addtask',function(req,res){
        console.log(req.body.data+"................."+req.body.email);
    MongoClient.connect(url, function(err, db) {

        if (err) throw err;
        var myobj={"email":req.body.email,"data":req.body.data,"status":0};
        db.collection('task').insert(myobj,function(err,resp){
            if(err) throw err;
            console.log("Task Added");
            db.collection('task').find({"email":req.body.email,"status":0}).toArray(function(err,items){
                if(err) throw err;
                db.collection('task').find({"email":req.body.email,"status":1}).toArray(function (err, comp) {
                    if(err) throw err;
                    res.render('todo',{email:req.body.email,item:items,completed:comp});
                });

            });
        })
    });

});


router.post('/del',urlencodeParser,function(req,res){
    MongoClient.connect(url, function(err, db) {
        assert.equal(null ,err);
        if (err) throw err;
        var myquery={email:req.body.email,data:req.body.delete,status:1};
        var myvalues={email:req.body.email,data:req.body.delete,status:2};
        db.collection('task').updateOne(myquery,myvalues,function(err,resp)
        {
            console.log("item deleted");
            if(err) throw err;
            db.collection('task').find({"email":req.body.email,"status":0}).toArray(function(err,items){
                if(err) throw err;
                db.collection('task').find({"email":req.body.email,"status":1}).toArray(function (err, comp) {
                    if(err) throw err;
                    db.collection('task').deleteMany({status:2});
                    res.render('todo',{email:req.body.email,item:items,completed:comp});
                });

            });


        })
    });

});





















router.post('/users/signup',function(req,res){
    res.render('signinnew');
});
router.post('/delete',urlencodeParser,function(req,res){
    MongoClient.connect(url, function(err, db) {
        assert.equal(null ,err);
        if (err) throw err;
        var myquery={email:req.body.email,data:req.body.delete,status:0};
        var myvalues={email:req.body.email,data:req.body.delete,status:1};
        db.collection('task').updateOne(myquery,myvalues,function(err,resp)
        {
            console.log("item deleted");
            if(err) throw err;
            db.collection('task').find({"email":req.body.email,"status":0}).toArray(function(err,items){
                if(err) throw err;
                db.collection('task').find({"email":req.body.email,"status":1}).toArray(function (err, comp) {
                    if(err) throw err;
                    res.render('todo',{email:req.body.email,item:items,completed:comp});
                });

            });


        })
    });

});
router.post('/users/insert',function(req,res){
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var myobj={first_name:req.body.first_name,last_name:req.body.last_name,email:req.body.email,pw:req.body.pw};
        db.collection("signup").insertOne(myobj,function(err,res){
            if (err) throw err;
            console.log("record inserted is"+res.first_name);
            db.close();
        })

    });
    res.render('sing2');
})


module.exports = router;
